public class Book extends WrittenItem {
 
public Book(int idNum, String title, int numOfCopies) {
super(idNum, title, numOfCopies);
 
    }
}


