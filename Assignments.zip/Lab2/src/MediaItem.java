
 public abstract class MediaItem extends Item {
private int runtime;
    MediaItem(int idNum,String title,int numOfCopies){
super(idNum,title,numOfCopies);
    }
public int getRuntime() {
return runtime;
    }
public void setRuntime(int runtime) {
this.runtime = runtime;
    }
 
}


