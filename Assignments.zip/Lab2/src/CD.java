
public class CD extends MediaItem{
private String artist;
private String genre;
    CD(int idNum, String title, int numOfCopies) {
super(idNum, title, numOfCopies);


    }
public String getArtist() {
return artist;
    }
public void setArtist(String artist) {
this.artist = artist;
    }
public String getGenre() {
return genre;
    }
public void setGenre(String genre) {
this.genre = genre;
    }
 
}



