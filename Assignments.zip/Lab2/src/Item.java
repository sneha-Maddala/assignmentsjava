public abstract class Item {
private int idNum;
private String title;
private int numOfCopies;
public Item(int idNum, String title, int numOfCopies) {
super();
this.idNum = idNum;
this.title = title;
this.numOfCopies = numOfCopies;
    }


 
public int getIdNum() {
return idNum;
    }
public void setIdNum(int idNum) {
this.idNum = idNum;
    }
public String getTitle() {
return title;
    }
public void setTitle(String title) {
this.title = title;
    }
public int getNumOfCopies() {
return numOfCopies;
    }
public void setNumOfCopies(int numOfCopies) {
this.numOfCopies = numOfCopies;
    }
@Override
public String toString() {
return"Item [idNum=" + idNum + ", title=" + title + ", numOfCopies=" + numOfCopies + "]";
    }
 
public boolean equals(Item i) {
return this.equals(i);
    }


public void print(){
        System.out.println();
    }


public boolean checkIn() {
return true;
    }


public boolean checkOut() {
return true;
    }
 
public void addItem() {


    }
 
}







