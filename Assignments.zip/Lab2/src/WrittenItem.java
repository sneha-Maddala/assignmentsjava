
public class WrittenItem {

	public WrittenItem(int idNum, String title, int numOfCopies) {
		// TODO Auto-generated constructor stub
	}

}
 