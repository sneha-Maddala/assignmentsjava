
import java.util.*;
public class SumOfCubes {
      public static int sumOfSeries(int n)
        {
            int sum = 0;
            for (int x=1; x<=n; x++)
                sum += x*x*x;
            return sum;
        }

        public static void main(String[] args)
        {
            System.out.println("enter n");
                Scanner sc=new Scanner(System.in);
               int s= sc.nextInt();
              SumOfCubes sobj=new SumOfCubes();
         
            int res=sobj.sumOfSeries(s);
            System.out.println(res);
        }
    }
 
