
    
package com.dao;


import java.util.ArrayList;


import com.bean.Employee;


public class Dao {
    ArrayList al=new ArrayList();
public void getDao(Employee obj) {
    al.add(obj);
//System.out.println(obj);
}
public Employee sendtoServ() {
    Employee emp=(Employee)al.get(0);
    return emp;
}
}
 





