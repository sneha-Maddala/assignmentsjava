package com.service;
import com.bean.Employee;
import com.dao.Dao;
public class EmpService {
    Dao d=new Dao();
public void getEmpService(Employee obj) {
    d.getDao(obj);
     }
public Employee sendtoUser() {
    return d.sendtoServ();
}
}
 





