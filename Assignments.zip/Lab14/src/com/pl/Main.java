
    
package com.pl;


public class Main {
    public static void main (String args[]) {
        User u=new User();
        u.getUser();
        u.sendtoMain();
    }
}
 



