
    
package com.pl;


import java.util.Scanner;
import com.bean.Employee;
import com.service.EmpService;


public class User {
    EmpService es=new EmpService();
void getUser() {
    
    System.out.println("enter id:");
    Scanner sc=new Scanner(System.in);
    int a=sc.nextInt();
    System.out.println("enter salary ");
    int b=sc.nextInt();
    System.out.println("enter NAME");
    String s1=sc.next();
    System.out.println("enter designation");
    String s2=sc.next();
    
    Employee em=new Employee(a,b,s1,s2);
    es.getEmpService(em);
    
}
public void sendtoMain() {
     Employee e1=es.sendtoUser();
     System.out.println(e1);
}
}
 




