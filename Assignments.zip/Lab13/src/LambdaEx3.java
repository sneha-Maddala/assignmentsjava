
import java.util.function.Predicate;
public class LambdaEx3 {
public static void main(String[] args)
{
    Predicate<String> getUserName = (i1) -> i1 == "mounicasiddu@gmail.com";


    // Creating predicate
    Predicate<String> getPassword = (i2) -> i2 == "123456";
    boolean result = getUserName.test("sneha.srija@gmail.com");
    System.out.println(result);


    // Calling Predicate method
    boolean result2 = getPassword.test("12345678");
    System.out.println(result2);
}
}
 




