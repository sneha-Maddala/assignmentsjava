

@FunctionalInterface
interface StringSpace
{
    String getString(String x);
}
public class LambdaEx2 {
    public static void main(String[] args) {
       
StringSpace ss=(v)->v.replace("", " ").trim();
String x=ss.getString("SRIJA");
System.out.println(x);
    }
}



