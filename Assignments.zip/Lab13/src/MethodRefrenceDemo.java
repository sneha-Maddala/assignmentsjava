import java.util.function.Consumer;
interface Number
{
    public void getNum();
}
 class MethodRefrenceDemoMain {
    int num;
        public int getNum() {
        return num;
    }
    public void setNum(int num) {
        this.num = num;
    }
}
class MethodRefrenceDemo
{
    public static void main(String[] args) {
        MethodRefrenceDemoMain mrd=new MethodRefrenceDemoMain();
        mrd.setNum(567);
        Consumer<MethodRefrenceDemoMain> c = MethodRefrenceDemoMain::getNum;
        //System.out.println(c.accept(mrd));
    }
}
 
