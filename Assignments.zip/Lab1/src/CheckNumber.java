import java.util.*;
 public class CheckNumber
 {
     public boolean checkNumber(int n)
     {
         while(n>1)
         {
             if(n%2!=0)
             {
                 return false;
                 }
             n=n/2;
             }
         return true;
         }
     public static void main(String args[])
     {
         CheckNumber check=new CheckNumber();
         Scanner sc=new Scanner(System.in);
         System.out.println("EnterYour Number:");
         int n=sc.nextInt();
         boolean bool=check.checkNumber(n);
         if(bool==true)
             System.out.println("Power of Two");
         else
             System.out.println("Not Power of Two");
         }
     }
 
