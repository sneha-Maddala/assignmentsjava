 import java.util.*;
  class Ex5_6 extends RuntimeException {
int salary;
Ex5_6(int salary) {
    //80000super();
    this.salary = salary;
    System.out.println("salary is below 3000 i.e.,"+salary);
}
     public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the salary");
        int salary=sc.nextInt();
        try {
            if(salary<3000)
                throw new Ex5_6(salary);
            else
                System.out.println("Salary is:"+salary);
        }
        catch(Exception e)
        {
            System.out.println("salary should be more than 3000");
        }
        System.out.println("remaining code");
    }
}
