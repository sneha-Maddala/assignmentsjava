import java.util.*;
public class Ex5_2 {
    public int myMethod(int n)
    {
        if(n<=2)
            return 1;
        else return myMethod(n-1)+myMethod(n-2);
    }
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter n value ");
        int n=sc.nextInt();
        Ex5_2 obj=new Ex5_2();
        System.out.println(obj.myMethod(n) );  
    }
}
 
