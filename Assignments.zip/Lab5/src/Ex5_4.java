import java.util.*;
public class Ex5_4 {
    static void NameException(String fName,String lName)
    {
        try {
            if(fName==null && lName==null)
            {
                throw new Exception("name should not be empty");
            }
            else {
                System.out.println(fName+" "+lName);
            }
            }
   
            catch(Exception e)
            {
                System.out.println(e);
            }   
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the first name");
        String firstName=sc.next();
        System.out.println("enter the last name");
        String lastName=sc.next();
        NameException(firstName,lastName);
            }
}
 

