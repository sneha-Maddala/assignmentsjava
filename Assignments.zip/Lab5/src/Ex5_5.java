import java.util.*;
public class Ex5_5 {
     static void validate(int eage)
    {
        try {
            if(eage<18)
                throw new ArithmeticException("Unable to vote"); 
            else 
                System.out.println("you can vote");
        }
        catch(ArithmeticException e){
            System.out.println(e);
            
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the age");
        int age=sc.nextInt();
        validate(age);
          }





}
 




