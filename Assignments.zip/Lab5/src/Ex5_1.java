  import java.util.*;
public class Ex5_1 {
int RED=1,YELLOW=2,GREEN=3,s;
public void mymethod(int s)
{
    switch(s) {
    case 1:
        System.out.println("STOP");
        break;
    case 2:
        System.out.println("READY");
        break;
    case 3:
        System.out.println("GO");
        break;
    }
}
public static void main(String args[])
{
    Scanner sc=new Scanner(System.in);
    System.out.println("enter your choice");
    int s=sc.nextInt();
    Ex5_1 obj=new Ex5_1();
    obj.mymethod(s);
    sc.close();
}
}
