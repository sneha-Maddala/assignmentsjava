 import java.util.*;
public class Ex5_3 {
public static void main(String args[])
{
    Scanner sc=new Scanner(System.in);
    System.out.println("enter n value ");
    int n=sc.nextInt();
    int count=0;;
    for(int i=1;i<n;i++)
    {
        for(int j=1;j<n;j++)
        {
            if(i%j==0)
            count+=1;
        }
        if(count==2)
        {
            System.out.println(i);
        }
        count=0;
    }
}
}
 
