
import java.util.StringTokenizer;
import java.util.*;
public class Ex1 {
    
    public static void main(String args[])
    {
        System.out.println("enter a line of integers:");
        @SuppressWarnings("resource")
        Scanner sc=new Scanner(System.in);
        String str=sc.next();
        StringTokenizer st=new StringTokenizer(str,".");
        int sum=0;
        while(st.hasMoreTokens())
        {
            int n=0;
            n=Integer.parseInt(st.nextToken());
            sum+=n;
            System.out.println("number is:"+n);
        }
        System.out.println(sum);
    }


}
 



