
import java.time.*;
import java.util.*;


public class Ex8_6 {  
    void getDate(int y,int m,int d)
    {
        LocalDate pdate = LocalDate.of(y, m, d);
        LocalDate now = LocalDate.now();
 
        Period diff = Period.between(pdate, now);
 
     System.out.printf("\nDifference is %d years, %d months and %d days \n\n", 
                    diff.getYears(), diff.getMonths(), diff.getDays());
    }
   public static void main(String[] args)
    {
       int d,m,y;
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter the date");
       d=sc.nextInt();
       System.out.println("Enter the month");
       m=sc.nextInt();
       System.out.println("Enter the year");
       y=sc.nextInt();
        Ex8_6 de=new Ex8_6();
        de.getDate(y,m,d);
  }
}



