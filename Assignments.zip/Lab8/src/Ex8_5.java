import java.util.Scanner;


public class Ex8_5 {
public static void main(String[] args) {
    System.out.println("Enter the String");
    Scanner sc=new Scanner(System.in);
    String str=sc.next();
    Ex8_5 pe=new Ex8_5();
    boolean x=pe.getPosNUm(str);
    System.out.println(x);
}


private boolean getPosNUm(String str) {
    boolean x=false;
    char arr[]=str.toCharArray();
    for(int i=0;i<arr.length;i++)
    {
        for(int j=0;j<arr.length;j++)
        {
        if((int)arr[i]<(int)arr[j])
        {
            System.out.println(arr[i]);
            System.out.println(arr[j]);
            x=true;
        }
        }
    }
    return x;
}
}





