import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
 
public class Ex8_4


{
   public static void main(String[] args) throws IOException
   {
       File temp;
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter the file you want to know the details");
       String temp1= sc.next();  
     
      temp = File.createTempFile(temp1, ".txt");
          
         boolean exists = temp.exists();
          
         System.out.println("Temp file exists : " + exists);
             
             System.out.println("is file excecutable?"+ temp.canExecute());//false
             System.out.println("is file readable?"+ temp.canRead());//false
             System.out.println("is file writable?"+ temp.canWrite());//false
             
             String fileName = temp.getName();
             if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
             System.out.println(fileName.substring(fileName.lastIndexOf(".")+1));
             
             System.out.println("length: "+ temp.length()); 
           }
         }
  



