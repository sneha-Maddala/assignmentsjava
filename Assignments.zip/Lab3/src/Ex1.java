import java.util.*;
public class Ex1 {
       static int getSecondSmallest(int a[], int n)
        {
            int temp;
            for(int i=0;i<=n;i++)
            {
                for(int j=i+1;j<n;j++)
                {
                    if(a[i]>a[j])
                    {
                    temp=a[i];
                    a[i]=a[j];
                    a[j]=temp;
                    }
                }
            }
            return a[1];
       
}
     public static void main(String args[])
       {
        int a[]= {20,3,50,9,8};
        Arrays.sort(a);
        System.out.println("The second smallest number:" +getSecondSmallest(a,5));
       
}
} 


