import java.util.Arrays;
import java.util.Scanner;
public class Ex3 {
    public static void main(String[] args) {
    System.out.println("enter the no of elements in the array");
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
        System.out.println("enter the elements of an array");
        int a[]=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i] = sc.nextInt();
        }
    int k=0;
int b[]=new int[a.length];
for(int i=a.length-1;i>=0;i--)
{
    b[k]=a[i];
    k++;   
}
Arrays.sort(b);
for(int i1=0;i1<a.length;i1++)
{
    System.out.println(b[i1]);
}
    }
}
 



