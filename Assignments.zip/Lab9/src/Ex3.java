import java.util.HashMap;
import java.util.Scanner;
public class Ex3 {
void Count1(int []arr)
    {
         HashMap<Integer, Integer> eachCharCountMap = new HashMap<Integer, Integer>();
for (int c : arr)
 {

 eachCharCountMap.put(c,c*c);

 }
 System.out.println(eachCharCountMap);
    }
public static void main(String[] args) {
    System.out.println("Enter the size of the list");
    Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int [] array = new int[n];
for(int i=0;i<n;i++)
 {
     array[i]=sc.nextInt();
 }
 Ex3 c=new Ex3();
 c.Count1(array);

}
}

