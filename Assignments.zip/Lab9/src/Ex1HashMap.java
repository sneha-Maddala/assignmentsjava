
    import java.util.*;
public class Ex1HashMap
{   
    List<Integer> getvalues(HashMap<Integer, String> h)
    {
        Set<Integer> s=h.keySet();
        List<Integer> l=new ArrayList<Integer>(s);
        Collections.sort(l);
     return l;
        }
    public static void main(String args[])
    {
        HashMap<Integer, String> h = new HashMap<Integer, String>();
        h.put(1,"hello");
        h.put(29,"shh");  
        h.put(3,"h r u");  
        Ex1HashMap hm = new Ex1HashMap();
        List<Integer> l1 = hm.getvalues(h);
        System.out.println(l1);
        System.out.println(h);
        }
}
 

