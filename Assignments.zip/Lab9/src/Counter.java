
import java.util.*;
public class Counter {
    void Count(char []arr)
    {
         HashMap<Character, Integer> eachCharCountMap = new HashMap<Character, Integer>();
        for (char c : arr)
        {
            if(eachCharCountMap.containsKey(c))
            {
                eachCharCountMap.put(c, eachCharCountMap.get(c)+1);
            }
            else
            {
                eachCharCountMap.put(c, 1);
            }
        }
        System.out.println(eachCharCountMap);
    }
public static void main(String[] args) {
    System.out.println("Enter the string");
    Scanner sc=new Scanner(System.in);
    String n=sc.next();
    char[] array = n.toCharArray();
    Counter c=new Counter();
    c.Count(array);
    
}
}


