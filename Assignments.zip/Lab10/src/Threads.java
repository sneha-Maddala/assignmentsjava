

import java.util.Date;


 class ThreadDemo implements Runnable {
    public void run() {
       
        try {
            while(true)
            {
                 System.out.println("Timer task started at:"+new Date());
            Thread.sleep(10000);
            }
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
}
public class Threads {
    public static void main(String args[]) {
     //SampleThread st=new SampleThread();
     //st.start();
        System.out.println("Main Method");
       ThreadDemo sti= new ThreadDemo();
       Thread t=new Thread(sti);
       t.start();
    }


} 
 





