import java.io.FileNotFoundException;
import java.io.FileReader;


public class FileProgram {    
        public void files() throws FileNotFoundException {
            FileReader fr = new FileReader("C:\\New folder\\source.txt");
            CopyDataThreadDemo();{
           
            }
            
        }


        private void CopyDataThreadDemo(FileReader fr) {
            // TODO Auto-generated method stub
            
        }


        private void CopyDataThreadDemo() {
            // TODO Auto-generated method stub
            
        }


        }
 






